<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('css/reponse_success.css')); ?>" rel="stylesheet">

<div class="card" id="card_success">
    <h4 class="card-header">Succès</h4>
    <div class="card-body">
        <p class="card-text">Votre réponse au formulaire <b><?php echo e($formulaire_name); ?></b> a bien été prise en compte.</p>
        <a href="<?php echo e(route('listeFormulaire')); ?>" class="btn btn-primary">Retourner à la liste des formulaires</a>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dev\Web\survey\src\resources\views/reponse/success.blade.php ENDPATH**/ ?>