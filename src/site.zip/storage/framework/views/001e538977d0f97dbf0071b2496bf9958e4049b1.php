<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('css/reponse_success.css')); ?>" rel="stylesheet">

<div class="card" id="card_success">
    <h4 class="card-header">Erreur 404</h4>
    <div class="card-body">
        <p class="card-text">Cette page n'existe pas</p>
        <a href="<?php echo e(route('home')); ?>" class="btn btn-primary">Retourner à l'accueil</a>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dev\Web\survey\src\resources\views/errors/404.blade.php ENDPATH**/ ?>