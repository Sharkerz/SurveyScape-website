<?php $__env->startSection('content'); ?>

list forms

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dev\Web\survey\src\resources\views/listeForm/index.blade.php ENDPATH**/ ?>
