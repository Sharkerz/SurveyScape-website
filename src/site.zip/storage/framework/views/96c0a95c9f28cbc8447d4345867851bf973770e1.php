<?php $__env->startSection('captcha'); ?>
    <?php echo htmlScriptTagJsApi(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('css/repondre.css')); ?>" rel="stylesheet">
<div id="back">
    <a href="javascript:window.history.go(-1)"><i id="back_logo" class="material-icons">arrow_back</i></a>
</div>
    <div class="container">

        <!-- Div titre du formulaire -->
        <div id="title">
            <h2><?php echo e($formulaire->name); ?></h2>
            <div id="auteur">
                <p class="float-right">
                    <img id="img_auteur" src="/Images/avatar/<?php echo e($formulaire->user->avatar); ?>">
                </p>
                <p class="name_auteur">
                    créé par <?php echo e($formulaire->user->name); ?>

                </p>
            </div>
        </div>

        <form method="post" id="form_reponse" action="<?php echo e(route('envoyer_reponse')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="form_id" value="<?php echo e($formulaire->id); ?>">

            <div id="questions">
            <!-- Questions -->
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="div_question">
                    <div class="question">
                        <h3> <?php echo e($question->name); ?> </h3>
                    </div>
                    <div class="proposition">
                        <input type="hidden" class="type_question" value="<?php echo e($question->type_question); ?>">

                        <!-- Reponse si choix multiples -->
                        <?php if($question->type_question == "Choix multiples"): ?>
                            <?php $__currentLoopData = $choix_question_multiples; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choix_question_multiple): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $choix_question_multiple; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choix_question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($choix_question->questions_id == $question->id): ?>
                                        <div class="form-check multiple_choice">
                                            <input name="<?php echo e($question->id); ?>" type="radio" class="form-check-input" id="<?php echo e($choix_question->id); ?>" value="<?php echo e($choix_question->name); ?>">
                                            <label class="form-check-label" for="<?php echo e($choix_question->id); ?>">
                                                <?php echo e($choix_question->name); ?>

                                            </label>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <!-- Reponse si Texte -->
                        <?php elseif($question->type_question == "Texte"): ?>
                                    <textarea class="form-control textarea" name="<?php echo e($question->id); ?>" rows="3" placeholder="Votre réponse..." required></textarea>
                        <?php endif; ?>
                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div id="envoyer">
                <?php echo htmlFormSnippet(); ?>

                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger" id="div_error">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><?php echo e($error); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
                <button type="submit" class="btn btn-primary btn-lg center-block" id="btn_envoyer">Envoyer</button>
            </div>

        </form>

    </div>

<!-- Si un background personnalisé existe -->
<?php if(isset($formulaire->background)): ?>
    <input type="text" id="background" value="<?php echo e($formulaire->background); ?>" hidden>
<?php endif; ?>


<script type="text/javascript" src="<?php echo e(URL::asset('js/repondre.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dev\Web\survey\src\resources\views/reponse/index.blade.php ENDPATH**/ ?>