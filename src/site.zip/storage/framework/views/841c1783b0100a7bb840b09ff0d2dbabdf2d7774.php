<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('css/list_form.css')); ?>" rel="stylesheet">

<div class="container-fluid" id="formulaire_list">
    <ul class="nav nav-tabs" id="tab" role="tablist">
        <li class="nav-item" role="presentation">
            <a class="nav-link active" id="public-tab" data-toggle="tab" href="#public" role="tab" aria-controls="public" aria-selected="true">Formulaires publics</a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link" id="friend-tab" data-toggle="tab" href="#friend" role="tab" aria-controls="friend" aria-selected="false">Formulaires partagés</a>
        </li>
    </ul>
    <div class="tab-content">

        <!-- formulaires publics -->
        <div class="tab-pane fade show active" id="public" role="tabpanel" aria-labelledby="public">
            <div id="header_list">
                <h2 class="header_title">Formulaires public disponibles</h2>
                <hr>
            </div>

            <?php echo e($formulaires->links()); ?>


            <?php $__currentLoopData = $formulaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formulaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="card formulaire" id="<?php echo e($formulaire->id); ?>">
                    <input type="hidden" class="form_token" value="<?php echo e($formulaire->token); ?>">
                    <img class="card-img-top" alt="Image_Formulaire" src="/Images/Formulaire/<?php echo e($formulaire->image); ?>">
                    <div class="card-body">
                        <h5 class="card-title titre_form"> <?php echo e($formulaire->name); ?> </h5>
                        <?php if($formulaire->close_on != NULL): ?>
                            <?php
                                setlocale(LC_ALL, 'fr');
                                    $time = $formulaire->close_on;
                                    $mois = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];
                                    $jour = date("d", strtotime($time));
                                    $annee = date("Y", strtotime($time));
                                    $m = date("m", strtotime($time));
                                    $moi = $mois[$m-1];
                                    $date = $jour.' '.$moi.' '.$annee;
                            ?>
                            <p class="card-text"> Disponible jusqu'au <?php echo e($date); ?></p>
                        <?php else: ?>
                            <p class="card-text"> Pas de <br> date limite </p>
                        <?php endif; ?>

                        <div class="auteur">
                            <?php echo e($formulaire->user->name); ?>

                            <img class="img_auteur" src="/avatar/<?php echo e($formulaire->user->avatar); ?>">
                        </div>

                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php echo e($formulaires->links()); ?>

        </div>

        <!-- formulaires partagés a l'utilisateur -->
        <div class="tab-pane fade" id="friend" role="tabpanel" aria-labelledby="public">

            <!-- un utilisateur est connecté -->
            <?php if( Auth::check() === true): ?>

                <div id="header_list">
                    <h2 class="header_title">Formulaires que vos amis vous partagent</h2>
                    <hr>
                </div>


                <?php $__currentLoopData = $partage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formulaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $formulaire; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card formulaire" id="<?php echo e($form->id); ?>">
                            <input type="hidden" class="form_token" value="<?php echo e($form->token); ?>">
                            <img class="card-img-top" alt="Image_Formulaire" src="/Images/Formulaire/<?php echo e($form->image); ?>">
                            <div class="card-body">
                                <h5 class="card-title titre_form"> <?php echo e($form->name); ?> </h5>
                                <?php if($form->close_on != NULL): ?>
                                    <?php
                                        setlocale(LC_ALL, 'fr');
                                            $time = $formulaire->close_on;
                                            $mois = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];
                                            $jour = date("d", strtotime($time));
                                            $annee = date("Y", strtotime($time));
                                            $m = date("m", strtotime($time));
                                            $moi = $mois[$m-1];
                                            $date = $jour.' '.$moi.' '.$annee;
                                    ?>
                                    <p class="card-text"> Disponible jusqu'au <?php echo e($date); ?></p>
                                <?php else: ?>
                                    <p class="card-text"> Pas de <br> date limite </p>
                                <?php endif; ?>

                                <div class="auteur">
                                    <?php echo e($form->user->name); ?>

                                    <img class="img_auteur" src="/avatar/<?php echo e($form->user->avatar); ?>">
                                </div>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <!-- invité -->
            <?php else: ?>

                <h1 id="error_friend"> Vous devez être connecté pour utiliser cette fonctionnalité.🤷‍♂️</h1>

            <?php endif; ?>

            <!-- formulaires partagés -->

        </div>

    </div>

</div>

<script type="text/javascript" src="<?php echo e(URL::asset('js/list_forms.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dev\Web\survey\src\resources\views/listeForm/index.blade.php ENDPATH**/ ?>