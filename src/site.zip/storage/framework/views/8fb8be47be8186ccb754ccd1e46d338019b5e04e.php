<?php $__env->startSection('content'); ?>

<?php
    //Import de class User
    use App\User;
?>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/Amis_list.css')); ?>" >


    <div id="div_amis" class="container">

        <div id="div_add_friend">
            <form action="<?php echo e(route('Amis.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <label id="label_add_friend" for="input_friend_invite">Ajouter un amis:</label>
                <input id="input_friend_invite" class="form-control" type="text" name="name" placeholder="Pseudo ou Email" required>
                <input type="submit" placeholder="Envoyer demande" class="btn btn-success bouton-creation">
            </form>

        </div>
        <br>
        <table class="table table-striped">
            <tbody>
            <?php if(@isset($name)): ?>
                <!-- Si l'utilisateur n'a pas d'amis -->
                <?php if (! ($name)): ?>
                    <hr>
                    <h1 id="no_friend_msg">Vous n'avez pas d'amis pour le moment🙁</h1>
                <?php else: ?>
                    <!-- Sinon, on les affiche -->
                    <?php $__currentLoopData = $name ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="friend-<?php echo e(User::where('name', $data)->first()->id); ?>">
                            <td>
                                <img alt="Amis-avatar" src="/avatar/<?php echo e(User::where('name', $data)->first()->avatar); ?>" class="amis-avatar">
                            </td>
                            <td>
                                <h1 id="name_friend"> <?php echo e($data); ?> </h1>
                            </td>
                            <td>
                                <i id="btn_delete_friend" data-toggle="modal" data-target="#window_delete_friend-<?php echo e(User::where('name', $data)->first()->id); ?>" class="material-icons">delete</i>

                                <!-- Modèle confirmer suppression de l'ami -->
                                <div class="modal fade" id="window_delete_friend-<?php echo e(User::where('name', $data)->first()->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Confirmation</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <p id="text_confirmation_delete_friend">
                                                    Voulez-vous vraiment supprimer <strong><?php echo e(User::where('name', $data)->first()->name); ?></strong> de vos amis? cette action est irréversible.
                                                </p>
                                            </div>
                                            <div class="modal-footer">
                                                <form method="post" id="form_delete_friend">
                                                    <input type="hidden" name="id_ami" value="<?php echo e(User::where('name', $data)->first()->id); ?>">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                                </form>
                                                <button type="button" class="btn btn-primary confirm_delete_friend" data-dismiss="modal" value="<?php echo e(User::where('name', $data)->first()->id); ?>">confirmer</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<!-- JQuery et Ajax-->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

<!-- Scripts suppression amis -->
<script type="text/javascript" src="<?php echo e(URL::asset('js/Amis.js')); ?>"></script>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dev\Web\survey\src\resources\views/Amis/index.blade.php ENDPATH**/ ?>