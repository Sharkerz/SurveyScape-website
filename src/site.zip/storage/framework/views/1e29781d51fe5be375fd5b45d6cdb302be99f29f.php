<?php $__env->startSection('content'); ?>


<link href="<?php echo e(asset('css/show_my_form.css')); ?>" rel="stylesheet">

<div id="back">
    <a href="<?php echo e(route('formulaires.index')); ?>"><i id="back_logo" class="material-icons">arrow_back</i></a>
</div>

<div class="card" id="window_share">
    <div class="card-header" id="header_share">
        <p>Partager le formulaire avec ses amis</p>
        <i class="material-icons" id="close_share">clear</i>
    </div>
    <div class="card-body" id="body_share">
        <div class="list-group" id="amis_list">
            <?php $__currentLoopData = $amis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ami): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="list-group-item list-group-item-action amis-item" data-value="<?php echo e($ami->id); ?>"><?php echo e($ami->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <form id="form_share" method="post" action="/partageform">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="form_id" value="<?php echo e($formulaire->id); ?>">
            <div id="amis_toshare">
            </div>
            <div id="btn_share">
                <button type="submit" class="btn btn-success">Partager</button>
            </div>
        </form>
    </div>
</div>

<div class="container">
    <input hidden value ="<?php echo e($formulaire->id); ?>">
    <!-- Div titre du formulaire -->

    <div id="title">
        <h2><?php echo e($formulaire->name); ?></h2>

        <h3 style="padding-left: 1.5rem">Il y a actuellement  :<?php echo e($nb_reponses); ?> réponses</h3>

        <div id="share_link">
            <p>Lien du formulaire: </p>
            <input class="form-control" id="input_sharelink" type="text" value="<?php echo e(Request::root()); ?>/repondre/<?php echo e($formulaire->token); ?>" readonly>
            <button id="btn_copy" type="button" class="btn btn-primary">Copier</button>
        </div>

        <div id="ronds_edit">
            <div id="Share_Form">
                <i class="material-icons"  id="btn-task">share</i>
            </div>
            <div id="Modify_Form">
                <i class="material-icons"  id="btn-task">create</i>
            </div>
            <div id="Delete_Form">
                <i class="material-icons"  id="btn-task">delete</i>
            </div>
        </div>

        <div class="alert alert-success" id="alert_copy" role="alert">
            Le lien de partage à bien été copié.
        </div>
    </div>

    <div id="questions">
    <?php
    $nb_question=1;
    $collect_data = [];
    ?>
        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
            <div class="div_question">
                <div class="question">
                    <h3>Question n°<?php echo e($nb_question); ?>:<?php echo e($question->name); ?></h3>
                </div>
                <?php if($question->type_question === "Choix multiples"): ?>
                    <?php if($nb_reponses != 0): ?>
             
                <div class ="Resultat_graphique">
                    <canvas id="canvas<?php echo e($nb_question); ?>" height="220" width="610">
                <?php
                        $table_question =[];
                    ?>
                    <?php
                        $table =[];
                    ?>
                <?php $__currentLoopData = $reponses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reponse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($reponse->question_id == $question->id): ?>
                        <?php
                            $temp = $reponse->response;
                            array_push($table,$temp);

                        ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php
                $data = (json_encode($table,JSON_UNESCAPED_SLASHES));
                $collect_data[$nb_question] =addslashes($data);
                ?>
            <script>
            var nb_question = '<?php echo($nb_question)?>';
            var data_send = '<?php echo($collect_data[$nb_question])?>';
            ;</script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.1.3/Chart.js"></script>
                <script>
                    //Pie Chart
                if(data_send!=""){
                    var test = JSON.parse( data_send );
                    var data = [];
                    var question = [];
                    var colors = [];
                    var colorArray = ['#e6194b', '#3cb44b', '#ffe119', '#4363d8', '#f58231', '#911eb4', '#46f0f0', '#f032e6', '#bcf60c', '#fabebe', '#008080', '#e6beff', '#9a6324', '#fffac8', '#800000', '#aaffc3', '#808000', '#ffd8b1', '#000075', '#808080'];
                    var nb_data = [];
                    for(var i=0; i <test.length;i++){
                        for (var key in nb_data){
                            if(test[i] == key){
                                nb_data[key] +=1;
                            }
                        }
                        if(nb_data[test[i]]  == null){
                            nb_data[test[i]] = 1;
                        }

                        };
                    for (var key in nb_data){
                            question.push(key);
                        }
                    ctx =  document.getElementById("canvas"+nb_question+"").getContext("2d");
                    function getRandomInt(max) {
                        return Math.floor(Math.random() * Math.floor(max));
                    }
                    var max_random = colorArray.length;
                    for (var key in nb_data){
                        data.push(nb_data[key]);
                    }
                    var labels =[];
                    var last_random = [];
                    for(var i=0; i <question.length;i++){
                        random = getRandomInt(max_random);
                        if(last_random.includes(random)){
                            random = getRandomInt(max_random);
                        }
                        colors.push(colorArray[random]);
                        last_random.push(random);
                        };
                    for(var i=0; i <question.length;i++){
                        labels.push(question[i])
                        };
                    new Chart(ctx,{
                        type: 'pie',
                        data: {
                            labels: labels,
                            datasets: [{
                                        data: data,
                                        backgroundColor:colors,
                                    }]
                            },
                    });
                }
                </script>
                    </canvas>
                </div>
                    <?php endif; ?>
                <?php elseif($question->type_question === "Texte"): ?>
                    <div class="Liste_Reponse">
                    <?php
                        $nb_reponses_question = 0
                        ?>
                        <?php $__currentLoopData = $reponses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reponse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($nb_reponses_question == 3): ?>
                                    <button type="button" class="btn btn-light Afficher_Reponses">Afficher toutes les réponses</button>
                                <div class="test">
                                <?php
                                $nb_reponses_question+=1
                                ?>
                            <?php elseif($reponse->question_id == $question->id && $nb_reponses_question <=3): ?>
                            <div class="Reponse_Texte"><?php echo e($reponse->response); ?></div>
                                <?php
                                $nb_reponses_question+=1
                                ?>
                            <?php elseif($reponse->question_id == $question->id && $nb_reponses_question >=3): ?>
                            <div  class="Reponse_Texte_cacher"><?php echo e($reponse->response); ?></div>
                                <?php
                                $nb_reponses_question+=1
                                ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endif; ?>

            </div>
            <?php
            $nb_question+=1
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>
<script type="text/javascript" src="<?php echo e(URL::asset('js/show_form.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<!-- Si un background personnalisé existe -->
<?php if(isset($formulaire->background)): ?>
    <input type="text" id="background" value="<?php echo e($formulaire->background); ?>" hidden>
<?php endif; ?>

<script>
    var id_form = '<?php echo e($formulaire->id); ?>' ;
</script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/Formulaire.js')); ?>"></script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dev\Web\survey\src\resources\views/formulaire/show.blade.php ENDPATH**/ ?>