<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('css/create_form.css')); ?>" rel="stylesheet">

<div id="back">
    <a href="javascript:window.history.go(-1)"><i id="back_logo" class="material-icons">arrow_back</i></a>
</div>

<div class="container">

    <div id="Add_Form">
        <div id="Add_Question"><i class="material-icons"  data-toggle="tooltip" data-placement="right" title="Ajouter une question" >add_circle_outline</i></div>
        <div id="Privacy"><i class="material-icons" id="btn-lock" data-toggle="tooltip" data-placement="right" title="Rendre le formulaire public" >lock</i></div>
        <div id="Add_Fond_Form"><i class="material-icons" id="btn-add_image_fond" data-toggle="tooltip" data-placement="right" title="Personnaliser le fond" >image</i></div>
        <form id="form_background" enctype="multipart/form-data" method="post">
            <?php echo csrf_field(); ?>
            <input  hidden id="image_fond" type="file" name="image_fond_form">
        </form>
    </div>

    <h1>Création d'un Formulaire</h1>
    <form enctype="multipart/form-data" action="<?php echo e(route('formulaires.store')); ?>" method="post">
        <?php echo csrf_field(); ?>

        <!-- Public/privé -->
            <input type="hidden" value="1" name="private" id="private_value">

        <div id="div_infos">
            <div class="Name_Form">
                <input class="NomFormulaire" type="text" maxlength="39" required name="name" data-rows="1" tabindex="0" placeholder="Nom du Formulaire">
            </div>
            <hr>
            <div class="row persoL1">
                <div class="col">
                    <label>Mettre une image en bannière: </label>
                    <input type="file" name="image">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="enableDate">
                        <label class="form-check-label" for="enableDate">
                            Définir une date de début et de fin
                        </label>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-6"></div>
                <div id="div_Date" class="col" hidden>
                    <label for="NomFormulaire">Début de la publication:</label>
                    <input type="date" id="start_date" name="open_on" value="null" min="2020-01-01"></br>
                    <label for="NomFormulaire">Fin de la publication:</label>
                    <input type="date" id="end_date" name="close_on" value="null" min="2020-01-01">
                </div>
            </div>

            <div class="row">
                <div class="col-10">
                </div>
                <div class="col-2" id="status_private" data-toggle="tooltip" data-placement="top" title="Les formulaires publics sont indexés sur le site. S'ils sont privés, il n'est possible d'y répondre qu'en possession du lien de partage">
                    <span>Formulaire</span> <span id="status_private_word">privé</span>
                </div>
            </div>

        </div>


    <div id="questions">
        <div class="div_question">
            <input type='hidden' value='1'>
                    <div class="body_question">
                        <!-- Ligne titre + choix type -->
                        <div class="row">
                            <div class="col-6">
                                <input type='hidden' id='id_question' name='id_q1'  value='1' >
                                <input type="text" class="form-control title_question" name="q1" placeholder="Question 1" required>
                            </div>
                            <div class="col"></div>
                            <div class="col-3">
                                <select class="form-control select_type" name="typeq1">
                                    <option value="Choix multiples"> Choix multiples</option>
                                    <option value="Texte"> Texte</option>
                                </select>
                            </div>
                            <div class="col-1"></div>
                        </div>

                        <!-- Case reponses questions -->
                        <div class="multipleChoice">
                            <input class="nb_choice" name="nb_choice" type="hidden" value="1"> <!-- Nombre de choix -->
                            <div class="choices">
                                <div class="row" id="choices">
                                    <div class="col-5">
                                        <input hidden  value="1-1" >
                                        <input type="text" name="1-1" class="form-control" placeholder="Choix 1" required>
                                    </div>
                                    <br><br>
                                </div>
                            </div>
                            <div class="row">
                                <i class="material-icons add_option">add</i>
                            </div>
                        </div>
                    </div>
        </div>
    </div>

    <div class="col" id="submit_form">
        <br><button type="submit" class="btn btn-primary btn-lg">Publier</button>
    </div>

    <div id="background_create">
        <!-- div qui accueil le background si selectionné -->
    </div>

</form>

<script type="text/javascript" src="<?php echo e(URL::asset('js/create_form.js')); ?>"></script>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dev\Web\survey\src\resources\views/formulaire/create.blade.php ENDPATH**/ ?>