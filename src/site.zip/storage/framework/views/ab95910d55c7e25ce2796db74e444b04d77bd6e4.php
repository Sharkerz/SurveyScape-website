<?php $__env->startSection('content'); ?>

    <link href="<?php echo e(asset('css/profile.css')); ?>" rel="stylesheet">

    <div id="contain_profil" class="container">
        <div id="profil_bar" class="row">
            <button type="button" class="btn btn-secondary btn_profil">Retour</button>
            <button type="button" class="btn btn-secondary btn_profil">Se déconnecter</button>
        </div>

        <img src="/avatar/<?php echo e($user->avatar); ?>" style="width:150px; height:150px; float:left; border-radius:50%; margin-right:25px;">

        <p> <?php echo e($user->name); ?></p>

        <h3>Changer photo de profil: </h3>
        <form enctype="multipart/form-data" action="<?php echo e(route('update_avatar')); ?>" method="POST">
            <label>Update Profile Image</label>
            <input type="file" name="avatar">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <input type="submit" class="pull-right btn btn-sm btn-primary">
        </form>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dev\Web\survey\src\resources\views/profil/edit.blade.php ENDPATH**/ ?>