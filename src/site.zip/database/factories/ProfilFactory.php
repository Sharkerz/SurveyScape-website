<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\profil;
use Faker\Generator as Faker;

$factory->define(profil::class, function (Faker $faker) {
    return [
        //
    ];
});
